from subprocess import call
import RPi.GPIO as GPIO
from time import sleep  


HIGH = 1
MID = 2
LOW = 3

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

GO = 18

GPIO.setup(GO, GPIO.OUT)


class information:
    status = 0
    priority = 0
    distance = 0
    
    def writestatus( value ):
        status = value
    def getstatus( ):
        return status  
    def getdist():
        return distance
    def getprior():
        return priority
    



def till_dist_halt(info):
    while info.getdist() != -1:         
        info.close()
        call ( "wget CLOUD_URL_HERE" )
        info = open("FILE_NAME", "rb")
    GPIO.output(GO, False )
        

while True:
    while True:                     
        call ( "wget CLOUD_URL_HERE" )
        info = open("FILE_NAME", "wb+")
        if ( info.getstatus() == 1):                
            break
	call("rm FILE_NAME")
    
    if ( info.getprior() == HIGH):
        if(info.getdist() < 1 ):        
            GPIO.output( GO, True )
       
    elif(info.getprior() == MID ):
        if(info.getdist() < .5 ):    
            GPIO.output( GO, True )
        
    elif(info.getprior() == LOW):
        if(info.getdist() < .2 ):      
            GPIO.output(GO,True)
        
    till_dist_halt()  

call("sudo python default.py")
exit()
